<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');

	}
	public function login()
	{
		// if ($this->user_id)
		if (false)

		{
			redirect('admin');
		}

		else
		{
			$data['title']		= "Admin - Login".$this->session->userdata('user_id');
			if (!empty($_POST))
			{
				$this->form_validation->set_rules('username', 'Username', 'trim|required');
		        $this->form_validation->set_rules('password', 'Password', 'trim|required');
		        if ($this->form_validation->run() == FALSE)
		        {
		        	$data['pesan'] ="Login gagal.<br>username atau password tidak tepat";
		        }

		        elseif ($_POST['username'] !="" && $_POST['password'] !="")
				{
					$this->load->model('user_model');
					$this->user_model->username = $_POST['username'];
					$this->user_model->password = $_POST['password'];
					$valid = $this->user_model->validasi_login();
					if ($valid)
					{
						$login = $this->user_model->cek_status_user();
						//var_dump($login);die;
						if ($login)
						{
							//die;
							 //logs
							$this->load->model('logs_model');
							$this->logs_model->user_id	 = $this->session->userdata('user_id');
		                	$this->logs_model->activity = "login ke aplikasi";
		                	$this->logs_model->category = "login";
		                	$desc = $_POST['username'];
		                	$this->logs_model->description = "dengan username ".$desc;
							$this->logs_model->insert();

							redirect('admin');


							die;
						}
						else
						{
							$data['pesan']	= "Login gagal.<br>Akun anda tidak aktif.";
						}
					}
					else
					{
						$data['pesan']	= "Login gagal.<br>username atau password tidak tepat";
					}
				}
				else
				{
					//echo"<script type='javascript'>alert('username atau Password tidak boleh kosong)');</script>";
					$data['pesan']	= "username atau Password tidak boleh kosong";
				}
			}
			$this->load->view('login',$data);
		}
	}
}
